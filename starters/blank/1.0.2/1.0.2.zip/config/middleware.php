<?php

return [
    "global" => [
        \Forge\Core\Http\Middlewares\CorsMiddleware::class,
        \Forge\Core\Http\Middlewares\SanitizeInputMiddleware::class,
        \Forge\Core\Http\Middlewares\CompressionMiddleware::class,
    ],
    "web" => [
        \Forge\Core\Http\Middlewares\SessionMiddleware::class,
        \Forge\Core\Http\Middlewares\CsrfMiddleware::class,
        \Forge\Core\Http\Middlewares\RelaxSecurityHeadersMiddleware::class,
    ],
    "api" => [
        \Forge\Core\Http\Middlewares\IpWhiteListMiddleware::class,
        // Needs ForgeDatabaseSql Module \Forge\Core\Http\Middlewares\ApiKeyMiddleware::class,
        \Forge\Core\Http\Middlewares\CookieMiddleware::class,
    ],
];
